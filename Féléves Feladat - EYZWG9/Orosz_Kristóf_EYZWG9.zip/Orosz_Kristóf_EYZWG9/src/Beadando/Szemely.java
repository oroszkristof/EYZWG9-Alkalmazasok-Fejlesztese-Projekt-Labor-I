package Beadando;

public abstract class Szemely {
    protected String nev;
    protected String azonosito;
    protected String cim;

    public Szemely(String nev, String azonosito, String cim) {
        this.nev = nev;
        this.azonosito = azonosito;
        this.cim = cim;
    }

    public String getNev() { return nev; }
    public void setNev(String nev) { this.nev = nev; }

    public String getAzonosito() { return azonosito; }
    public void setAzonosito(String azonosito) { this.azonosito = azonosito; }

    public String getCim() { return cim; }
    public void setCim(String cim) { this.cim = cim; }
}
