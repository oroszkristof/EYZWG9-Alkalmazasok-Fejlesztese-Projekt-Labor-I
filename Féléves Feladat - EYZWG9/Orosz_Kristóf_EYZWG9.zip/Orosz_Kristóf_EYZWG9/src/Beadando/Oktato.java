package Beadando;

import java.util.ArrayList;
import java.util.List;

public class Oktato extends Szemely {

    private String intezet;
    private String beosztas;
    private List<Tantargy> tantargyak = new ArrayList<>();

    public Oktato(String nev, String azonosito, String cim, String intezet, String beosztas) {
        super(nev, azonosito, cim);
        this.intezet = intezet;
        this.beosztas = beosztas;
    }

    public void hozzaadTantargy(Tantargy t) {
        tantargyak.add(t);
    }
    
    public void rogzitesJegy(Vizsga v, Hallgato h, int jegy) {
        v.rogzitesJegy(h, jegy);
    }

    @Override
    public String toString() {
        return "Oktato {\n" +
               "\tNév: " + nev + ",\n" +
               "\tAzonosító: " + azonosito + ",\n" +
               "\tCím: " + cim + ",\n" +
               "\tIntézet: " + intezet + ",\n" +
               "\tBeosztás: " + beosztas + ",\n" +
               "\tTantárgyak: " + tantargyak + "\n" +
               "}";
    }


}
