package Beadando;

import java.util.ArrayList;
import java.util.List;

public class Hallgato extends Szemely {
    private String neptunKod;
    private boolean aktiv;
    private List<Tantargy> tantargyak = new ArrayList<>();
    private int maxKredit = 30;

    public Hallgato(String nev, String azonosito, String cim, String neptunKod) {
        super(nev, azonosito, cim);
        this.neptunKod = neptunKod;
        this.aktiv = true;
    }

    public void regisztralTantargy(Tantargy t) {
        int osszKredit = tantargyak.stream().mapToInt(Tantargy::getKredit).sum();
        if (osszKredit + t.getKredit() <= maxKredit) {
            tantargyak.add(t);
            t.regisztralHallgato(this);
        } else {
            System.out.println("Nem lehet regisztralni, túl sok kredit!");
        }
    }

    public void jelentkezikVizsgara(Vizsga v) {
        v.jelentkezikVizsgara(this);
    }

    public void setAktiv(boolean aktiv) {
        this.aktiv = aktiv;
    }

    public boolean isAktiv() {
        return aktiv;
    }

    @Override
    public String toString() {
        return "Hallgato {\n" +
               "\tNeptun kód: '" + neptunKod + "',\n" +
               "\tAktív: " + aktiv + ",\n" +
               "\tTantárgyak: " + tantargyak + ",\n" +
               "\tMax kredit: " + maxKredit + "\n" +
               "}";
    }

}
