package Beadando;

import java.util.ArrayList;
import java.util.List;

public class Tantargy {
    private String nev;
    private String kod;
    private int kredit;
    private List<Hallgato> regisztraltHallgatok = new ArrayList<>();

    public Tantargy(String nev, String kod, int kredit) {
        this.nev = nev;
        this.kod = kod;
        this.kredit = kredit;
    }

    public String getNev() { return nev; }
    public String getKod() { return kod; }
    public int getKredit() { return kredit; }

    public void regisztralHallgato(Hallgato h) {
        regisztraltHallgatok.add(h);
    }

    public List<Hallgato> getRegisztraltHallgatok() {
        return regisztraltHallgatok;
    }
    
    @Override
    public String toString() {
        return nev + " (" + kod + ", " + kredit + " kredit)";
    }

}
