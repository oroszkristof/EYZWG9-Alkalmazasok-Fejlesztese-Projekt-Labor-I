package Beadando;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Vizsga {
    private Tantargy tantargy;
    private Date datum;
    private Map<Hallgato, Integer> jegyek = new HashMap<>();

    public Vizsga(Tantargy tantargy, Date datum) {
        this.tantargy = tantargy;
        this.datum = datum;
    }

    public void jelentkezikVizsgara(Hallgato h) {
        jegyek.putIfAbsent(h, null);
    }

    public void rogzitesJegy(Hallgato h, int jegy) {
        if (jegyek.containsKey(h)) {
            jegyek.put(h, jegy);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Vizsga {\n");
        sb.append("\tTantárgy: ").append(tantargy).append(",\n");
        sb.append("\tDátum: ").append(datum).append(",\n");
        sb.append("\tJegyek:\n");
        for (Map.Entry<Hallgato, Integer> entry : jegyek.entrySet()) {
            sb.append("\t\t").append(entry.getKey().getNev())
              .append(": ").append(entry.getValue()).append("\n");
        }
        sb.append("}");
        return sb.toString();
    }

}


