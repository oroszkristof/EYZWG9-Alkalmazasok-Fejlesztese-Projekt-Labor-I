package Beadando;

public class Adminisztrator extends Szemely{

    public Adminisztrator(String nev, String azonosito, String cim) {
        super(nev, azonosito, cim);
    }

    public void modositStatusz(Hallgato h, boolean aktiv) {
        h.setAktiv(aktiv);
    }

    public void rogzitesJegy(Vizsga v, Hallgato h, int jegy) {
        v.rogzitesJegy(h, jegy);
  
    }

    @Override
    public String toString() {
        return "Adminisztrátor {\n" +
               "\tNév: " + nev + ",\n" +
               "\tAzonosító: " + azonosito + ",\n" +
               "\tCím: " + cim + "\n" +
               "}";
    }


}
