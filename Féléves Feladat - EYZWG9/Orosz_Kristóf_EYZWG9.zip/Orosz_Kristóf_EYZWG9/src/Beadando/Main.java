package Beadando;

import java.util.Date;

public class Main {
    public static void main(String[] args) {
        Tantargy prog = new Tantargy("Programozás Alapjai", "PROG100", 5);
        Tantargy adatbazis = new Tantargy("Adatbáziskezelés", "DB101", 3);
        Tantargy op = new Tantargy("Operációs rendszerek", "OP102", 3);
        Tantargy adatszerkezet = new Tantargy("Adatszerkezetek és algoritmusok", "DB103", 5);
        Tantargy matek = new Tantargy("Numerikus matematika", "DB104", 5);

        Hallgato h1 = new Hallgato("Kiss Péter", "", "Tokaj Hegyalja Egyetem", "HAEEW23");
        
        
        Hallgato h2 = new Hallgato("Orosz Kristóf", "ABC123", "Tokaj Hegyalja Egyetem", "BEAGH55");
        h2.regisztralTantargy(prog);
        h2.regisztralTantargy(adatbazis);
        h2.regisztralTantargy(adatszerkezet);
        h2.regisztralTantargy(matek);
        
        Hallgato h3 = new Hallgato(" Kovács Tamás", "ADC123", "Tokaj Hegyalja Egyetem", "AQDVT5");
        h3.regisztralTantargy(prog);
        h3.regisztralTantargy(adatbazis);
        h3.regisztralTantargy(adatszerkezet);
        h3.regisztralTantargy(matek);
        
        Hallgato h4 = new Hallgato("Nagy István", "ADF123", "Tokaj Hegyalja Egyetem", "BEHKH41");
        h4.regisztralTantargy(prog);
        h4.regisztralTantargy(matek);

        Oktato okt1 = new Oktato("Dr. Nagy Ákos", "O456", "Tokaj-Hegyalja Egyetem", "Comenius Intézet", " Egyetemi adjunktus");
        okt1.hozzaadTantargy(prog);
        okt1.hozzaadTantargy(adatszerkezet);
        okt1.hozzaadTantargy(matek);
        
        Oktato okt2 = new Oktato("Dr. Kiss János", "O456", "Tokaj-Hegyalja Egyetem", "Comenius Intézet", " Egyetemi docens");
        okt2.hozzaadTantargy(op);
        okt2.hozzaadTantargy(adatbazis);
        
        
        Adminisztrator admin = new Adminisztrator("Molnár Anna", "A789", "Tokaj - Hegyalja Egyetem");
        admin.modositStatusz(h1, false);

        Adminisztrator adminhely = new Adminisztrator("Kiss Noel", "A789", "Tokaj - Hegyalja Egyetem");
        admin.modositStatusz(h1, false);
        
        
        Vizsga vizsga1 = new Vizsga(prog, new Date());
        h1.jelentkezikVizsgara(vizsga1);
        h2.jelentkezikVizsgara(vizsga1);
        admin.rogzitesJegy(vizsga1, h1, 4);
        admin.rogzitesJegy(vizsga1, h2, 4);

        System.out.println(h1);
        System.out.println(h2);
        System.out.println(h3);
        System.out.println(h4);
        System.out.println(vizsga1);
        System.out.println(prog);              
        System.out.println(adatbazis);
        System.out.println(op);
        System.out.println(adatszerkezet);
        System.out.println(matek);
        System.out.println(okt1);
        System.out.println(okt2);
        System.out.println(admin);
        System.out.println(adminhely); 

        
    }
}